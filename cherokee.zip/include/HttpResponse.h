#pragma once
#include "HttpData.h"

using HttpResponse = HttpData;
