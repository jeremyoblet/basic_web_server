#pragma once

#include "HttpData.h"

using HttpRequest = HttpData;